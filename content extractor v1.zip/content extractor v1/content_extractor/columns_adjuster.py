import pandas as pd
import math


class COLUMN_ADJUSTER:
    '''
    Input is panadas df object
    '''
    def __init__(self, df):
        self.df = df

    def find_headers_starting_point(self):
        # Find Header starting point
        dff = self.df.to_dict('list')
        self.head_id = 0
        for id, k in enumerate(dff[0]):
            if isinstance(k, str):
                self.head_id = id-1
                break

    def forward_fill(self, check_characters = ['$']):
        #Forward Fill
        for cc in check_characters:
            df = self.df.to_dict('list')
            items = df.items()
            del_ids = []
            for id, value in items:
                c_count = value.count(cc)
                if c_count>=1:
                    x = df[id]
                    y = df[id+1]
                    if isinstance(y[self.head_id], float):

                        dummy_list = []
                        for j, l  in list(zip(x,y)):
                            if isinstance(j, str):
                                j= j
                            elif not isinstance(j, str):

                                j = str(j) if not math.isnan(j) else ''
                            if isinstance(l, str):
                                l = l
                            elif not isinstance(l, str):
                                l = str(l) if not math.isnan(l) else ''
                            dummy_list.append(j+l)
                        df[id] = dummy_list
                        del_ids.append(id+1)

            for k in del_ids:
                del df[k]
            df = pd.DataFrame(df)
            dummy_columns = {k:id for id, k in enumerate(df.columns.tolist())}
            df.rename(columns=dummy_columns, inplace=True)
            self.df = df

    def backward_fill(self, check_characters = [')']):

        #Backward Fill
        for cc in check_characters:
            df = self.df.to_dict('list')
            items = df.items()
            del_ids = []
            for id, value in items:
                c_count = value.count(cc)
                if c_count>=1:
                    x = df[id-1]
                    y = df[id]
                    if isinstance(x[self.head_id], str):
                        dummy_list = []
                        for j, l  in list(zip(x,y)):
                            if isinstance(j, str):
                                j= j
                            elif not isinstance(j, str):
                                j = str(j) if not math.isnan(j) else ''

                            if isinstance(l, str):
                                l = l
                            elif not isinstance(l, str):
                                l = str(l) if not math.isnan(l) else ''
                            dummy_list.append(j+l)
                        df[id-1] = dummy_list
                        del_ids.append(id)


            for k in del_ids:
                del df[k]
            df = pd.DataFrame(df)
            dummy_columns = {k: id for id, k in enumerate(df.columns.tolist())}
            df.rename(columns=dummy_columns, inplace=True)
            self.df = df


    def make_heads(self):
        df = self.df.replace('', math.nan, regex=True)

        heads = df.loc[:self.head_id, :]
        heads.ffill(axis=1, inplace=True)
        heads = heads.replace(math.nan, '' , regex=True)
        heads = heads.values.tolist()

        dummy_heads = heads[0]
        for k in range(1,len(heads)):
            dummy_heads = [ ':'.join(l).strip(':') for l in list(zip(dummy_heads, heads[k]))]

        values = df.loc[self.head_id+1:, :].values.tolist()
        df = pd.DataFrame(values, columns=dummy_heads)
        return df

    def run_column_adjuster(self):
        self.find_headers_starting_point()
        self.forward_fill()
        self.backward_fill()
        return self.make_heads()


