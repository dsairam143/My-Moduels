

import lxml.html
import lxml.html as LH
from bs4 import BeautifulSoup


class HTMLEXTRACTOR:
    '''
    This class designed for extract html related data or content.
    '''
    def __init__(self, content):
        self.content = content

    def html_big_div(self, main_path, sub_paths):
        '''
        :param main_path:  parent xpath. The xpath should be string
        :param sub_paths:  required xpaths to extract data. The sub_paths should be list of list like
        [['name', 'type', 'path'], ['name', 'type', 'path']]
        :return: returns json data with required data
        '''
        root = LH.fromstring(self.content)
        main_div = root.xpath(main_path)
        div_content = lxml.html.tostring(main_div[0])
        divs = BeautifulSoup(div_content).find('body').findNext()
        sub_divs_data = []
        for div in divs.findChildren(recursive=False):
            product_dict = dict()
            for pPath in sub_paths:
                x_path = pPath[2]
                try:
                    div = str(div)
                    tree = lxml.html.fromstring(div)
                    sub_div = tree.xpath(x_path)
                    sub_html = lxml.html.tostring(sub_div[0])
                    jsoup = BeautifulSoup(sub_html)

                    if pPath[1] == 'text':
                        value = jsoup.text.strip()
                    elif pPath[1] == 'href' or pPath[1] == 'a':
                        value = jsoup.find('a')['href']
                    elif pPath[1] == 'src' or pPath[1] == 'img':
                        value = jsoup.find('img')['src']
                    elif 'attrs' in pPath[1]:
                        value = jsoup.find('body').findChild().attrs[pPath[1].split('|')[-1]]
                        if isinstance(value, list):
                            value = ' '.join(value)

                    product_dict[pPath[0]] = value

                except Exception as e:
                    product_dict[pPath[0]] = None
            sub_divs_data.append(product_dict)
        return sub_divs_data
